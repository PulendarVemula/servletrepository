package com.createiq.studentregistration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentRegistration
 */
public class StudentRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentRegistration() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter printWriter = response.getWriter();

		String sname = request.getParameter("sname");
		String srname = request.getParameter("srname");
		String sid = request.getParameter("sid");
		String mobileno = request.getParameter("mobileno");
		String emailid = request.getParameter("emailid");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String course = request.getParameter("course");
		String color = request.getParameter("color");

		String name = sname + " " + srname;

		printWriter.println("<h3>Student Name      : " + name + "</h3>");
		printWriter.println("<h3>Student id        : " + sid + "</h3>");
		printWriter.println("<h3>Student mobile No : " + mobileno + "</h3>");
		printWriter.println("<h3>Student emailid   : " + emailid + "</h3>");
		printWriter.println("<h3>Student DOB       : " + dob + "</h3>");
		printWriter.println("<h3>Student Gender    : " + gender + "</h3>");
		printWriter.println("<h3>Student Course    : " + course + "</h3>");
		printWriter.println("<h3>Student F.color   : " + color + "</h3>");

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "vemula5", "1234");
			preparedStatement = connection
					.prepareStatement("INSERT INTO STUDENT_REGISTRATION(sname, srname, sid, mobileno, emailid, dob, gender, course, color) VALUES (?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, sname);
			preparedStatement.setString(2, srname);
			preparedStatement.setString(3, sid);
			preparedStatement.setString(4, mobileno);
			preparedStatement.setString(5, emailid);
			preparedStatement.setString(6, dob);
			preparedStatement.setString(7, gender);
			preparedStatement.setString(8, course);
			preparedStatement.setString(9, color);
			preparedStatement.executeUpdate();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		printWriter.println("<h4>You are successfully registered</h4>");
	}

}
